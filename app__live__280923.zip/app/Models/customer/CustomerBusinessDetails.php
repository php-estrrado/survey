<?php

namespace App\Models\customer;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerBusinessDetails extends Model
{
    use HasFactory;
    protected $table = 'user_business_details';
    protected $guarded = [];

    }
