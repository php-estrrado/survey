(function($) {
	"use strict";
	
	
	const ps1 = new PerfectScrollbar('.message-menu', {
	  useBothWheelAxes:false,
	  suppressScrollX:false,
	});
	
	const ps2 = new PerfectScrollbar('.notify-menu', {
	  useBothWheelAxes:false,
	  suppressScrollX:false,
	});
	
	
})(jQuery);