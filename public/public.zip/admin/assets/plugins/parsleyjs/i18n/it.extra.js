// Validation errors messages for Parsley
// Load this after Parsley

Parsley.addMessages('it', {
  dateiso: "Inserire una data valida (AAAA-MM-GG)."
});
